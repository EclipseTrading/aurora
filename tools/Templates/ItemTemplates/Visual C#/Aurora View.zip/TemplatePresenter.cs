﻿using Aurora.Core;

namespace $rootnamespace$.Views.$safeitemname$
{
    public class $safeitemname$Presenter : Presenter<$safeitemname$ViewModel, $safeitemname$View, $safeitemname$ActivityInfo>
    {
        public $safeitemname$Presenter($safeitemname$ActivityInfo viewActivityInfo) : base(viewActivityInfo)
        {
        }
    }
}
