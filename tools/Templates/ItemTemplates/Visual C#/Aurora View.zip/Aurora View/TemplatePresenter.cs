﻿using Aurora.Core;
using Aurora.Core.Actions;

namespace $rootnamespace$.Views.$safeitemname$
{
    public class $safeitemname$Presenter : ViewPresenter<$safeitemname$ViewModel, $safeitemname$ActivityInfo>
    {
        public $safeitemname$Presenter($safeitemname$ActivityInfo viewActivityInfo, IActionHandlerService actionHandlerService) : base(viewActivityInfo, actionHandlerService)
        {
        }
    }
}
