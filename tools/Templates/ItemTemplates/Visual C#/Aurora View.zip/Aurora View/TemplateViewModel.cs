﻿using Aurora.Core;

namespace $rootnamespace$.Views.$safeitemname$
{
    public class $safeitemname$ViewModel : ViewModelBase
    {
    }
}
