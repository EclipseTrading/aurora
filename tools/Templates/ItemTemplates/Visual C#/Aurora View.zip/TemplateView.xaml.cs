﻿namespace $rootnamespace$.Views.$safeitemname$
{
    /// <summary>
    /// Interaction logic for TemplateView.xaml
    /// </summary>
    public partial class $safeitemname$View
    {
        public $safeitemname$View()
        {
            InitializeComponent();
        }
    }
}
