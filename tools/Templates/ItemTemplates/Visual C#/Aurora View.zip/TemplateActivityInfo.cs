﻿using Aurora.Core.Activities;
using Aurora.Core.Container;

namespace $rootnamespace$
{
    public class $safeitemname$ActivityInfo : ViewActivityInfo
    {
        public $safeitemname$ActivityInfo(string title, HostLocation location = HostLocation.Center, bool isCloseable = false) : base(title, location, isCloseable)
        {
        }
    }
}
